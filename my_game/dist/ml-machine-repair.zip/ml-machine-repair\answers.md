# Answer Key

1. B
2. C
3. D
4. B
5. C
6. B
7. C
8. D
9. B
10. C
